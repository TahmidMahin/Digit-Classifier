#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
#define debug(a) printf("%s %lld\n", #a, a)
#define start_timer() mdouble st=clock();
#define stop_timer() double en=clock(); printf("%lf\n",(en-st)/CLOCKS_PER_SEC);
 
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("train.txt", "r", stdin);
        // start_timer();
    #endif

    FILE *images = fopen("images.txt", "w");
    FILE *expected_results = fopen("expected results.txt", "w");

    int lc1, lc2, in;
    char ins[11000], c;

    cin >> ins;

    for(lc1 = 1; lc1 <= 42000; lc1++)
    {
        for(lc2 = 1; lc2 <= 785; lc2++)
        {
            scanf("%d", &in);
            if(lc2 != 785) 
            {
                getchar();
                // cout << c;
            }

            // cout << in << endl;

            if(lc2 == 1)
            {
                fprintf(expected_results, "%d\n", in);
            }
            else
            {
                fprintf(images, "%d", in);
                if(!(lc1 == 42000 && lc2 == 785)) fprintf(images, "\n");
            }
        }
    }

    // stop_timer();
    return 0;
}
